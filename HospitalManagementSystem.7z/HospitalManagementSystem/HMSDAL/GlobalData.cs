﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSDAL
{
    static class GlobalData
    {
        public static string ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog = Training_23Jan19_Mumbai; Persist Security Info=True;User ID = sqluser; Password=sqluser";
    }
}
